import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.*;

public class MessageQueue {
    private static int n_ids;

    public static void main(String[] args) throws InterruptedException {
	BlockingQueue<Message> queue = new LinkedBlockingDeque<>(10);

	// //Part 2 & 3
	// Producer p1 = new Producer(queue, n_ids++);
	// Producer p2 = new Producer(queue, n_ids++);
	// Consumer c1 = new Consumer(queue, n_ids++);
	// Consumer c2 = new Consumer(queue, n_ids++);
	// new Thread(p1).start();
	// new Thread(p2).start();
	// new Thread(c1).start();
	// new Thread(c2).start();

	//Part 4
	Scanner reader = new Scanner(System.in);

	System.out.println("Enter amount of consumers: ");
	int n = reader.nextInt();
	ArrayList<Consumer> consumers = new ArrayList<>();
	for(int i = 0; i < n; i++){
		Consumer c = new Consumer(queue, n_ids++);
		consumers.add(c);
		new Thread(c).start();
	}

	System.out.println("Enter amount of producers: ");
	int pr = reader.nextInt();
	ArrayList<Producer> producers = new ArrayList<>();
	for(int i = 0; i < pr; i++){
		Producer p = new Producer(queue, n_ids++);
		producers.add(p);
	}
	for(Producer startP: producers){
		new Thread(startP).start();
	}

	try {
	    Thread.sleep(10000);
	} catch (InterruptedException e) {
	    e.printStackTrace();
	}
	// //Part 3
	// p1.stop();
	// p2.stop();

	//Part 4
	for(Producer stopP: producers){
		stopP.stop();
	}

	int difference = n - pr;
	if(difference > 0){
		for(int i = 0; i < difference; i++){
			queue.put(new Message("stop"));
		}
	}

	}

}
